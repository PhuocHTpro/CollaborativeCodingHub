﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollaborativeCodingClient.Models.Packets.Project
{
    public class UpdateFileContentRequest
    {
        public int FileID { get; set; }
        public string Content { get; set; }
    }
}
