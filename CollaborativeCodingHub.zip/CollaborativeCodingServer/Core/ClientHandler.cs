﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using CollaborativeCodingServer.Protocol;
using CollaborativeCodingServer.Services;
using CollaborativeCodingServer.Models;

namespace CollaborativeCodingServer.Core
{
    public class ClientHandler
    {
        private readonly TcpClient client; 
        private readonly NetworkStream stream;
        private readonly AuthService authService = new AuthService();
        private readonly ProjectService projectService = new ProjectService();

        public ClientHandler(TcpClient client)
        {
            this.client = client;
            stream = client.GetStream();
        }

        public void Start()
        {
            byte[] buffer = new byte[4096];

            try
            {
                while (true)
                {
                    int bytesRead = stream.Read(buffer, 0, buffer.Length);

                    if (bytesRead == 0)
                    {
                        Console.WriteLine("[SERVER] Client Disconnected");
                        break;
                    }

                    string json = Encoding.UTF8.GetString(buffer, 0, bytesRead);

                    Packet packet = JsonHelper.Deserialize(json);

                    switch (packet.Type)
                    {
                        case "CHAT":
                            HandleChat(packet);
                            break;

                        case "LOGIN":
                            HandleLogin(packet);
                            break;

                        case "REGISTER":
                            HandleRegister(packet);
                            break;

                        case "CREATE_ROOM":
                            HandleCreateRoom(packet);
                            break;

                        case "JOIN_ROOM":
                            HandleJoinRoom(packet);
                            break;

                        case "CREATE_PROJECT":
                            HandleCreateProject(packet);
                            break;

                        default:
                            Console.WriteLine("[SERVER] Unknown Packet");
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                stream.Close();
                client.Close();
            }
        }

        private void Send(string message)
        {
            byte[] data = Encoding.UTF8.GetBytes(message);

            stream.Write(data, 0, data.Length);
        }

        public string Username { get; set; }

        private void HandleChat(Packet packet)
        {
            if (CurrentRoom == null)
            {
                Send("YOU_ARE_NOT_IN_ROOM");
                return;
            }

            string message = $"[{CurrentRoom.RoomName}] {Username}: {packet.Data}";

            Console.WriteLine(message);

            BroadcastToRoom(message);
        }

        private void HandleLogin(Packet packet)
        {
            LoginRequest request = JsonHelper.Deserialize<LoginRequest>(packet.Data);

            bool success = authService.Login(request.Username, request.Password);

            if (success)
            {
                Send("LOGIN_SUCCESS");
            }
            else
            {
                Send("LOGIN_FAILED");
            }
        }

        private void HandleRegister(Packet packet)
        {
            RegisterRequest request = JsonHelper.Deserialize<RegisterRequest>(packet.Data);

            bool success = authService.Register(request.Username, request.Password);

            if (success)
            {
                Send("REGISTER_SUCCESS");
            }
            else
            {
                Send("REGISTER_FAILED");
            }
        }

        private void HandleCreateRoom(Packet packet)
        {
            CreateRoomRequest request = JsonHelper.Deserialize<CreateRoomRequest>(packet.Data);

            Room room = new Room
            {
                RoomId = Guid.NewGuid().ToString(),
                RoomName = request.RoomName
            };

            room.Clients.Add(this);

            CurrentRoom = room;

            RoomManager.Rooms.Add(room);

            Console.WriteLine($"[ROOM CREATED] {room.RoomName}");

            Send($"CREATE_ROOM_SUCCESS|{room.RoomId}");
        }

        public Room CurrentRoom { get; set; }

        private void HandleJoinRoom(Packet packet)
        {
            JoinRoomRequest request = JsonHelper.Deserialize<JoinRoomRequest>(
                    packet.Data);

            Room room = RoomManager.Rooms.FirstOrDefault(r => r.RoomId == request.RoomId);

            if (room == null)
            {
                Send("ROOM_NOT_FOUND");
                return;
            }

            room.Clients.Add(this);

            CurrentRoom = room;

            Console.WriteLine($"[JOIN ROOM] {room.RoomName}");

            Send("JOIN_ROOM_SUCCESS");
        }

        private void BroadcastToRoom(string message)
        {
            if (CurrentRoom == null)
                return;

            foreach (ClientHandler client in CurrentRoom.Clients)
            {
                client.Send(message);
            }
        }

        private void HandleCreateProject(Packet packet)
        {
            CreateProjectRequest request = JsonHelper.Deserialize<CreateProjectRequest>(packet.Data);

            bool success = projectService.CreateProject(request.ProjectName, request.RoomID);

            if (success)
            {
                Send("CREATE_PROJECT_SUCCESS");
            }
            else
            {
                Send("CREATE_PROJECT_FAILED");
            }
        }
    }
}
