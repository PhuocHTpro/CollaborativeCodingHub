﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollaborativeCodingServer.Models.Packets.Project
{
    public class OpenFileRequest
    {
        public int FileID { get; set; }
    }
}
