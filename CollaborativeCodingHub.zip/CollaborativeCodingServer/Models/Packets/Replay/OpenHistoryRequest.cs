﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollaborativeCodingServer.Models.Packets.Replay
{
    public class OpenHistoryRequest
    {
        public int HistoryID { get; set; }
    }
}
